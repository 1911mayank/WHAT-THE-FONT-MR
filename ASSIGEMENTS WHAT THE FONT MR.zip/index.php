<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<title> Diss To Drake</title>
		
		<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
		<!-- STEP 1: Build a LINK element to attach the EXTERNAL style sheet located in the 'css' folder - the CSS file is called, 'styles.css' - don't forget to add the rel attribute equal to 'stylesheet' -->
    <link rel="stylesheet" href="css/styles.css" media="screen">

		
	</head>
	<body id="section1">
		<!-- Page-level header -->
		<header>
 		
			<h1>Diss To Kid</h1>

		</header>
		<!-- Page-level main content -->
		<main>
			<!-- News Section -->
			<section>
				<h3>Author: MC Stan</h3>
        <time datetime="2023-03-29">March 29, 2019</time>
				<p>Yo, Emiway Bantai, you think you're the king
But I'm MC Stan, here to bring the sting
You claim to be the rap god in the scene
But let me show you what real rap means</p>
				<!-- First Article -->
				<article>
				
				
					<p>This is the diss track, Emiway, brace yourself
I'm here to expose your shallow wealth
You're a product of gimmicks and hype
But I'll dismantle your empire, overnight</p>
				</article>
				<!-- Second Article -->
				<article>
					
					
					<p>You started from the streets, I'll give you that
But your skills are nothing more than chat
You rely on autotune to hide your flaws
But I'll spit raw lyrics, break your false applause</p>
				</article>
				<!-- Third Article -->
				<article>
					
					
					<p>This is the diss track, Emiway, brace yourself
I'm here to expose your shallow wealth
You're a product of gimmicks and hype
But I'll dismantle your empire, overnight</p>
				</article>
			</section>
			<!-- Side Notes / Related Information -->
			<aside>
			
					
					   <img src="sddefault.jpg", width= "180" height="300" />
					
				
			</aside>
		</main>
		
	</body>
</html>
